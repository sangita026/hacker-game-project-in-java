package com.escapethelostworld;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.util.*;
import java.util.List;


class GameFrame extends JFrame {
    final GamePanel panel;
    GameFrame() {
        setTitle("ESCAPE: THE LOST WORLD");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280, 760);
        setLocationRelativeTo(null);
        setResizable(false);
        panel = new GamePanel();
        setContentPane(panel);
    }
}


package com.escapethelostworld;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.util.*;
import java.util.List;


class GamePanel extends JPanel implements ActionListener, KeyListener {
    Screen screen=Screen.MENU; final SaveManager save=new SaveManager(); final SoundManager sound=new SoundManager(); final GameDatabase db=new GameDatabase();
    final Random random=new Random(); final javax.swing.Timer timer=new javax.swing.Timer(16,this);
    int charIndex, worldIndex; boolean soundOn, musicOn, sfxOn; String difficulty;
    String cameraMode, charSizeMode;
    long lastFrame=System.nanoTime();
    Screen settingsReturn=Screen.MENU;
    double distance=0, speed=360, lanePos=1, laneTarget=1, jump=0, verticalVel=0, slide=0, startMusicTime=0;
    double spawnClock=2.0, coinClock=.3, monsterDistance=185, threat=0; double monsterChaseTime=5.7; boolean monsterActive=true; int score=0, coins=0, combo=1, mistakes=0;
    boolean playing=false, paused=false, magnet=false, shield=false, boost=false, nearMiss=false;
    double magnetTime=0, shieldTime=0, boostTime=0, messageTime=0; String message="";
    final List<Obstacle> obstacles=new ArrayList<>(); final List<Coin> coinList=new ArrayList<>(); final List<Power> powers=new ArrayList<>();
    int missionCoins=0, missionJumps=0, missionRuns=0;
    Rectangle playBtn=new Rectangle(), backBtn=new Rectangle();
    Font titleFont=new Font("SansSerif",Font.BOLD,46), headFont=new Font("SansSerif",Font.BOLD,28), uiFont=new Font("SansSerif",Font.BOLD,16);

    GamePanel(){setFocusable(true);addKeyListener(this);addMouseListener(new MouseAdapter(){ public void mouseClicked(MouseEvent e){GamePanel.this.mousePressed(e.getX(),e.getY());} });timer.start();soundOn=save.sound();musicOn=save.music();sfxOn=save.sfx();difficulty=save.difficulty();cameraMode=save.camera();charSizeMode=save.charSize();
sound.setEnabled(soundOn);sound.setMusicEnabled(musicOn&&soundOn);sound.setSfxEnabled(sfxOn&&soundOn);charIndex=save.selectedChar();worldIndex=save.selectedWorld();sound.playMenuMusic();}
    void go(Screen s){screen=s; requestFocusInWindow(); if(s==Screen.MENU) sound.playMenuMusic();}
    void openSettings(){settingsReturn=screen; if(screen==Screen.GAME) paused=true; go(Screen.SETTINGS);}
    void closeSettings(){Screen target=settingsReturn; screen=target; requestFocusInWindow(); if(target==Screen.MENU) sound.playMenuMusic(); else if(target==Screen.GAME){sound.playRunMusic();} }
    void applyAudio(){soundOn=musicOn||sfxOn;save.sound(soundOn);save.music(musicOn);save.sfx(sfxOn);sound.setMusicEnabled(musicOn&&soundOn);sound.setSfxEnabled(sfxOn&&soundOn);if(!musicOn||!soundOn)sound.stopMusic();else if(screen==Screen.MENU)sound.playMenuMusic();}
    void resetGame(){
        screen=Screen.GAME;
        requestFocusInWindow();
        distance=0;speed=360;lanePos=1;laneTarget=1;jump=0;verticalVel=0;slide=0;startMusicTime=1.9;spawnClock=2.0;coinClock=.4;monsterDistance=185;threat=0;score=0;coins=0;combo=1;mistakes=0;
        magnet=false;shield=false;boost=false;magnetTime=shieldTime=boostTime=0;message="GO!";messageTime=1.2;obstacles.clear();coinList.clear();powers.clear();playing=true;paused=false;missionRuns++;sound.playStartMusic();
    }
    public void actionPerformed(ActionEvent e){
        long now=System.nanoTime(); double dt=Math.min(.035,(now-lastFrame)/1e9); lastFrame=now;
        if(screen==Screen.GAME && playing && !paused) update(dt);
        repaint();
    }
    void update(double dt){
        double difficultyFactor = difficulty.equals("EASY") ? 0.90 : (difficulty.equals("HARD") ? 1.12 : 1.0);
        speed=Math.min(610*difficultyFactor,360*difficultyFactor+distance*.012*difficultyFactor);
        if(boost){speed+=180;boostTime-=dt;if(boostTime<=0)boost=false;}
        if(startMusicTime>0){ startMusicTime-=dt; if(startMusicTime<=0){ sound.playChaseMusic(); sound.roar(); } } else if(monsterActive){ sound.playChaseMusic(); } else { sound.playRunMusic(); }
        distance += speed*dt/10.0; score=(int)(distance*2)+coins*10+combo*3;
        lanePos += (laneTarget-lanePos)*Math.min(1,dt*12);
        if(jump>0 || verticalVel!=0){jump+=verticalVel*dt;verticalVel-=1200*dt;if(jump<=0){jump=0;verticalVel=0;}}
        if(slide>0) slide-=dt;
        spawnClock-=dt; coinClock-=dt;
        if(spawnClock<=0){spawnObstacle();double minSpawn=difficulty.equals("EASY")?5.8:(difficulty.equals("HARD")?4.0:5.0);double maxExtra=difficulty.equals("EASY")?1.3:(difficulty.equals("HARD")?.7:1.1);spawnClock=minSpawn+random.nextDouble()*maxExtra;}
        if(coinClock<=0){spawnCoins();coinClock=.65+random.nextDouble()*.5;}
        for(Obstacle o:obstacles)o.z-=speed*dt;
        for(Coin c:coinList)c.z-=speed*dt;
        for(Power p:powers)p.z-=speed*dt;
        checkCollisions();
        obstacles.removeIf(o->o.z<-80);coinList.removeIf(c->c.z<-80);powers.removeIf(p->p.z<-80);
        if(magnet){magnetTime-=dt;if(magnetTime<=0)magnet=false;}
        if(shield){shieldTime-=dt;if(shieldTime<=0)shield=false;}
        if(messageTime>0)messageTime-=dt;

        // The monster only chases for the opening 5–6 seconds. Then it leaves the run.
        if(monsterActive){
            monsterChaseTime-=dt;
            monsterDistance=Math.max(70,monsterDistance-dt*6);
            threat=1-monsterChaseTime/5.7;
            if(monsterChaseTime<=0){
                monsterActive=false;
                threat=0;
                message="YOU ESCAPED THE MONSTER!";
                messageTime=1.6;
                monsterDistance=220; sound.playRunMusic();
            }
        } else {
            threat=0;
        }

        if(distance>=5000){
            playing=false;
            save.best(score);
            db.recordRun(CharacterCatalog.DATA[charIndex].name,WorldType.values()[worldIndex].title,coins,score,distance,0,"VICTORY");
            go(Screen.VICTORY);
            sound.playVictoryMusic();
        }
        mistakes=0;
    }
    int missesForDatabase(){ return Math.max(0, Math.min(3, (int)Math.round(threat*3))); }

    void spawnObstacle(){
        int lane=random.nextInt(3); int type=random.nextInt(6); obstacles.add(new Obstacle(lane,560,type));
        if(random.nextDouble()<.23) powers.add(new Power(random.nextInt(3),690,random.nextInt(4)));
    }
    void spawnCoins(){
        int lane=random.nextInt(3); int count=3+random.nextInt(4); for(int i=0;i<count;i++)coinList.add(new Coin(lane,470+i*48));
    }
    void checkCollisions(){
        for(Obstacle o:obstacles){
            if(o.z<70 && o.z>-35 && Math.abs(lanePos-o.lane)<.35){
                boolean safe=(o.type==1 && jump>45)||(o.type==2 && slide>0)||(o.type==4 && jump>70);
                if(!safe && !o.hit){
                    o.hit=true;
                    playing=false;
                    // Collision ends the run immediately. The score is kept exactly as it is.
                    save.best(score);
                    sound.play(3);
                    sound.playGameOverMusic();
                    db.recordRun(CharacterCatalog.DATA[charIndex].name,WorldType.values()[worldIndex].title,coins,score,distance,1,"GAME_OVER");
                    message=randomReaction();
                    messageTime=1.0;
                    go(Screen.GAMEOVER);
                    return;
                }
            }
            if(!o.passed && o.z<0){o.passed=true;if(Math.abs(lanePos-o.lane)<.55 && !o.hit){score+=35;combo=Math.min(8,combo+1);}}
        }
        Iterator<Coin> it=coinList.iterator();
        while(it.hasNext()){Coin c=it.next();
            if(c.z<65&&c.z>-25&&(magnet||Math.abs(lanePos-c.lane)<.38)){
                coins++;missionCoins++;score+=10*combo;sound.play(0);it.remove();
            }
        }
        Iterator<Power> ip=powers.iterator();
        while(ip.hasNext()){
            Power p=ip.next();
            if(p.z<65&&p.z>-25&&Math.abs(lanePos-p.lane)<.45){activatePower(p.type);ip.remove();}
        }
    }
    String randomReaction(){String[] a={"OH!","EEE!","OUCH!","WHOOPS!","OOF!","WATCH OUT!"};return a[random.nextInt(a.length)];}
    void activatePower(int t){switch(t){case 0-> {magnet=true;magnetTime=8;message="MAGNET!";}case 1->{shield=true;shieldTime=9;message="SHIELD!";}case 2->{boost=true;boostTime=4;message="SPEED BOOST!";}case 3->{jump=Math.max(jump,140);verticalVel=0;message="SUPER JUMP!";}}messageTime=1.2;sound.play(2);}

    protected void paintComponent(Graphics g){super.paintComponent(g);Graphics2D gg=(Graphics2D)g.create();gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);switch(screen){case MENU->drawMenu(gg);case CHARACTERS->drawCharacters(gg);case WORLDS->drawWorlds(gg);case SHOP->drawShop(gg);case MISSIONS->drawMissions(gg);case SETTINGS->drawSettings(gg);case GAME->drawGame(gg);case GAMEOVER->drawEnd(gg,false);case VICTORY->drawEnd(gg,true);}gg.dispose();}
    void bg(Graphics2D g,Color a,Color b){GradientPaint p=new GradientPaint(0,0,a,0,getHeight(),b);g.setPaint(p);g.fillRect(0,0,getWidth(),getHeight());}
    void rounded(Graphics2D g,int x,int y,int w,int h,Color c){g.setColor(c);g.fillRoundRect(x,y,w,h,22,22);}
    void text(Graphics2D g,String s,int x,int y,Font f,Color c){g.setFont(f);g.setColor(c);g.drawString(s,x,y);}
    void center(Graphics2D g,String s,int x,int y,Font f,Color c){g.setFont(f);g.setColor(c);FontMetrics m=g.getFontMetrics();g.drawString(s,x-m.stringWidth(s)/2,y);}
    void button(Graphics2D g,String s,Rectangle r,Color c){rounded(g,r.x,r.y,r.width,r.height,c);center(g,s,r.x+r.width/2,r.y+r.height/2+7,new Font("SansSerif",Font.BOLD,18),Color.WHITE);}

    void drawMenu(Graphics2D g){
        WorldType w=WorldType.FOREST; drawWorldBackground(g,w,true);
        rounded(g,42,28,448,675,new Color(255,255,255,232));
        center(g,"ESCAPE",266,93,new Font("SansSerif",Font.BOLD,54),new Color(248,171,38));
        center(g,"THE LOST WORLD",266,145,new Font("SansSerif",Font.BOLD,45),new Color(110,78,166));
        center(g,"RUNNER",266,184,new Font("SansSerif",Font.BOLD,28),new Color(220,82,134));
        center(g,"A cinematic endless runner adventure",266,216,new Font("SansSerif",Font.PLAIN,17),new Color(76,76,88));
        Rectangle r=new Rectangle(78,246,356,56);button(g,"PLAY",r,new Color(67,181,101));playBtn=r;
        Rectangle[] rs={new Rectangle(78,316,356,45),new Rectangle(78,369,356,45),new Rectangle(78,422,356,45),new Rectangle(78,475,356,45),new Rectangle(78,528,356,45)};
        button(g,"CHARACTERS",rs[0],new Color(79,112,205));
        button(g,"WORLDS",rs[1],new Color(92,145,214));
        button(g,"SHOP",rs[2],new Color(225,151,63));
        button(g,"MISSIONS",rs[3],new Color(128,100,190));
        button(g,"SETTINGS",rs[4],new Color(91,92,116));
        center(g,"BEST SCORE  "+save.best(),170,618,uiFont,new Color(72,72,82));
        center(g,"COINS  "+save.coins(),360,618,uiFont,new Color(177,122,20));
        center(g,"Audio: "+(musicOn?"MUSIC ON":"MUSIC OFF")+"  •  "+difficulty,266,650,new Font("SansSerif",Font.PLAIN,14),new Color(92,100,112));
        drawMonster(g,1010,535,1.25);drawCharacter(g,835,540,charIndex,1.45,false);
        center(g,"RUN  •  DODGE  •  ESCAPE",935,680,new Font("SansSerif",Font.BOLD,22),Color.WHITE);
    }
    void drawWorldBackground(Graphics2D g,WorldType w,boolean menu){
        bg(g,w.sky,new Color(247,245,232));
        g.setColor(new Color(255,255,255,150));for(int i=0;i<7;i++){int x=70+i*190;int y=70+(i%3)*38;g.fillOval(x,y,120,38);g.fillOval(x+45,y-18,80,55);} 
        if(w==WorldType.FOREST){for(int i=0;i<11;i++){drawTree(g,40+i*125,360+(i%3)*30,.75+(i%2)*.18);}}
        else if(w==WorldType.DESERT){for(int i=0;i<8;i++)drawCactus(g,70+i*160,390+(i%2)*35,.9);}
        else if(w==WorldType.CITY){for(int i=0;i<9;i++)drawBuilding(g,30+i*150,250+(i%3)*45,80,180-(i%3)*25);}
        else if(w==WorldType.SNOW){for(int i=0;i<10;i++)drawSnowTree(g,45+i*135,370+(i%2)*25,.9);}
        else if(w==WorldType.VOLCANO){drawVolcano(g,980,275,1.7);for(int i=0;i<7;i++)drawRock(g,70+i*170,400+(i%2)*30,1);}
        else {for(int i=0;i<7;i++)drawCloudIsland(g,60+i*185,400+(i%3)*30,1);}
    }
    void drawCharacters(Graphics2D g){
        bg(g,new Color(236,230,249),new Color(246,246,252));
        text(g,"Choose Your Runner",55,65,titleFont,new Color(62,58,92));text(g,"10 unique characters • 5 boys + 5 girls",58,93,uiFont,new Color(105,101,125));
        for(int i=0;i<10;i++){int col=i%5,row=i/5,x=40+col*242,y=125+row*275;rounded(g,x,y,220,250,new Color(255,255,255,225));drawCharacter(g,x+110,y+142,i,0.80,false);center(g,CharacterCatalog.DATA[i].name,x+110,y+196,new Font("SansSerif",Font.BOLD,19),new Color(55,55,70));center(g,CharacterCatalog.DATA[i].outfit,x+110,y+218,new Font("SansSerif",Font.PLAIN,14),new Color(110,108,120));if(i==charIndex) {g.setColor(new Color(74,190,109));g.setStroke(new BasicStroke(4));g.drawRoundRect(x+4,y+4,212,242,18,18);center(g,"EQUIPPED",x+110,y+246,uiFont,new Color(50,160,85));}}
        button(g,"← BACK",new Rectangle(30,690,150,45),new Color(91,92,116));
    }
    void drawWorlds(Graphics2D g){
        bg(g,new Color(230,241,249),new Color(247,239,220));text(g,"Choose Your World",55,65,titleFont,new Color(54,70,88));text(g,"Six colorful places to escape through",58,93,uiFont,new Color(90,105,115));
        WorldType[] ws=WorldType.values();for(int i=0;i<6;i++){int col=i%3,row=i/3,x=45+col*410,y=125+row*260;rounded(g,x,y,380,230,new Color(255,255,255,225));drawMiniWorld(g,ws[i],x+15,y+15,350,155);text(g,(i+1)+". "+ws[i].title,x+22,y+197,new Font("SansSerif",Font.BOLD,19),new Color(58,65,78));if(i==worldIndex){text(g,"SELECTED",x+260,y+198,uiFont,new Color(60,180,96));}}
        button(g,"← BACK",new Rectangle(30,690,150,45),new Color(91,92,116));
    }
    void drawMiniWorld(Graphics2D g,WorldType w,int x,int y,int ww,int hh){g.setClip(x,y,ww,hh);g.setColor(w.sky);g.fillRect(x,y,ww,hh);g.setColor(w.distant);g.fillOval(x-40,y+65,ww+100,120);g.setColor(w.road);Path2D p=new Path2D.Double();p.moveTo(x+100,y+hh);p.lineTo(x+135,y+80);p.lineTo(x+215,y+80);p.lineTo(x+250,y+hh);p.closePath();g.fill(p);if(w==WorldType.FOREST){drawTree(g,x+55,y+90,.65);drawTree(g,x+290,y+95,.7);drawMushroom(g,x+230,y+105,.55);}else if(w==WorldType.DESERT){drawCactus(g,x+70,y+115,.6);drawCactus(g,x+280,y+120,.55);}else if(w==WorldType.CITY){drawBuilding(g,x+40,y+45,60,110);drawBuilding(g,x+260,y+30,70,125);}else if(w==WorldType.SNOW){drawSnowTree(g,x+60,y+100,.7);drawSnowTree(g,x+290,y+100,.7);}else if(w==WorldType.VOLCANO){drawVolcano(g,x+270,y+55,.8);}else {drawCloudIsland(g,x+50,y+105,.7);drawCloudIsland(g,x+280,y+105,.65);}g.setClip(null);}
    void drawShop(Graphics2D g){bg(g,new Color(255,240,211),new Color(240,226,250));text(g,"Adventure Shop",55,65,titleFont,new Color(86,65,72));text(g,"Coins: "+save.coins(),58,95,uiFont,new Color(180,120,35));String[] names={"Character Outfit","Trail Sparkle","Lucky Pet","Coin Pack"};for(int i=0;i<4;i++){int x=55+i*305;rounded(g,x,140,275,420,new Color(255,255,255,220));center(g,names[i],x+137,185,new Font("SansSerif",Font.BOLD,21),new Color(65,65,75));if(i<3)drawCharacter(g,x+137,332,(i+2)%10,0.92,false);else {for(int j=0;j<5;j++)drawCoin(g,x+80+j*28,300+(j%2)*50,1);}center(g,i==3?"+250 COINS":"COMING WITH YOUR RUN",x+137,480,uiFont,new Color(105,105,120));button(g,i==3?"CLAIM +250":"EQUIPPED",new Rectangle(x+45,505,185,45),new Color(98,153,212));}button(g,"← BACK",new Rectangle(30,690,150,45),new Color(91,92,116));}
    void drawMissions(Graphics2D g){bg(g,new Color(232,241,255),new Color(247,236,224));text(g,"Missions & Rewards",55,65,titleFont,new Color(58,72,96));text(g,"Complete goals while you run",58,93,uiFont,new Color(100,110,125));String[] m={"Collect 200 coins","Jump 15 times","Reach 1500 distance","Finish one full run"};String[] reward={"+100","+75","+200","+300"};for(int i=0;i<4;i++){int y=145+i*125;rounded(g,55,y,1120,95,new Color(255,255,255,220));text(g,m[i],85,y+37,new Font("SansSerif",Font.BOLD,21),new Color(65,68,78));text(g,"Reward "+reward[i]+" coins",85,y+67,uiFont,new Color(176,122,32));int val=switch(i){case 0->Math.min(200,missionCoins);case 1->Math.min(15,missionJumps);case 2->Math.min(1500,(int)distance);default->missionRuns;};int max=switch(i){case 0->200;case 1->15;case 2->1500;default->1;};g.setColor(new Color(225,231,238));g.fillRoundRect(500,y+28,450,20,12,12);g.setColor(new Color(76,185,108));g.fillRoundRect(500,y+28,(int)(450.0*val/max),20,12,12);text(g,val+" / "+max,975,y+45,uiFont,new Color(75,75,85));}button(g,"← BACK",new Rectangle(30,690,150,45),new Color(91,92,116));}
    void drawSettings(Graphics2D g){
        bg(g,new Color(232,237,246),new Color(247,241,232));
        center(g,"GAME SETTINGS",640,66,new Font("SansSerif",Font.BOLD,42),new Color(57,64,82));
        center(g,"Personalize audio, difficulty, camera and runner size",640,96,new Font("SansSerif",Font.PLAIN,16),new Color(96,103,116));
        rounded(g,190,115,900,555,new Color(255,255,255,240));

        settingRow(g,"Background Music",musicOn?"ON":"OFF",157,musicOn?new Color(70,171,103):new Color(150,150,160),new Rectangle(850,132,150,42));
        settingRow(g,"Sound Effects",sfxOn?"ON":"OFF",213,sfxOn?new Color(70,171,103):new Color(150,150,160),new Rectangle(850,188,150,42));

        text(g,"Difficulty",245,283,new Font("SansSerif",Font.BOLD,20),new Color(58,62,75));
        button(g,"EASY",new Rectangle(500,250,140,42),difficulty.equals("EASY")?new Color(70,171,103):new Color(173,177,186));
        button(g,"NORMAL",new Rectangle(650,250,150,42),difficulty.equals("NORMAL")?new Color(79,112,205):new Color(173,177,186));
        button(g,"HARD",new Rectangle(810,250,140,42),difficulty.equals("HARD")?new Color(213,101,92):new Color(173,177,186));

        text(g,"Camera Angle",245,352,new Font("SansSerif",Font.BOLD,20),new Color(58,62,75));
        button(g,"CINEMATIC",new Rectangle(500,319,175,42),cameraMode.equals("CINEMATIC")?new Color(86,113,186):new Color(173,177,186));
        button(g,"CLASSIC",new Rectangle(690,319,150,42),cameraMode.equals("CLASSIC")?new Color(86,113,186):new Color(173,177,186));

        text(g,"Runner Size",245,421,new Font("SansSerif",Font.BOLD,20),new Color(58,62,75));
        button(g,"SMALL",new Rectangle(500,388,140,42),charSizeMode.equals("SMALL")?new Color(90,151,194):new Color(173,177,186));
        button(g,"NORMAL",new Rectangle(650,388,150,42),charSizeMode.equals("NORMAL")?new Color(79,112,205):new Color(173,177,186));
        button(g,"LARGE",new Rectangle(810,388,140,42),charSizeMode.equals("LARGE")?new Color(177,119,75):new Color(173,177,186));

        text(g,"Controls",245,478,new Font("SansSerif",Font.BOLD,20),new Color(58,62,75));
        text(g,"A / ←  Move left",405,478,new Font("SansSerif",Font.PLAIN,15),new Color(75,81,92));
        text(g,"D / →  Move right",590,478,new Font("SansSerif",Font.PLAIN,15),new Color(75,81,92));
        text(g,"W / ↑ / SPACE  Jump",800,478,new Font("SansSerif",Font.PLAIN,15),new Color(75,81,92));
        text(g,"S / ↓  Slide",405,508,new Font("SansSerif",Font.PLAIN,15),new Color(75,81,92));
        text(g,"P  Pause",590,508,new Font("SansSerif",Font.PLAIN,15),new Color(75,81,92));
        text(g,"Settings save automatically and apply to your next run.",245,557,new Font("SansSerif",Font.PLAIN,14),new Color(108,112,122));
        button(g,"RESET PROGRESS",new Rectangle(245,594,185,42),new Color(210,91,104));
        button(g,"BACK",new Rectangle(455,594,150,42),new Color(91,92,116));
        button(g,"APPLY & BACK",new Rectangle(625,594,185,42),new Color(67,154,112));
    }
    void settingRow(Graphics2D g,String label,String value,int y,Color c,Rectangle r){text(g,label,250,y,new Font("SansSerif",Font.BOLD,22),new Color(58,62,75));button(g,value,r,c);}

    void drawGame(Graphics2D g){
        drawRunnerWorld(g,WorldType.values()[worldIndex]);
        // HUD
        rounded(g,22,18,310,58,new Color(255,255,255,205));text(g,"COINS "+coins,42,54,new Font("SansSerif",Font.BOLD,21),new Color(172,119,17));text(g,"SCORE "+score,155,54,uiFont,new Color(60,70,80));
        rounded(g,345,18,280,58,new Color(255,255,255,205));text(g,"DIST "+(int)distance+" / 5000",365,54,uiFont,new Color(65,72,82));
        rounded(g,930,18,315,58,new Color(255,255,255,205));
        if(monsterActive){
            text(g,"THE HUNTER IS CLOSE",950,43,uiFont,new Color(90,65,80));
            g.setColor(new Color(230,227,235));g.fillRoundRect(1060,30,150,16,10,10);
            g.setColor(new Color(222,88,105));
            g.fillRoundRect(1060,30,(int)(150*Math.max(0,Math.min(1,1-monsterChaseTime/5.7))),16,10,10);
        } else {
            text(g,"THE HUNTER IS GONE",950,43,uiFont,new Color(73,152,99));
            g.setColor(new Color(88,185,116));g.fillRoundRect(1060,30,150,16,10,10);
        }
        text(g,"P",1210,58,uiFont,new Color(80,80,90));
        if(shield||magnet||boost){int x=30; if(shield){powerBadge(g,x,95,"SHIELD",new Color(82,147,220));x+=120;}if(magnet){powerBadge(g,x,95,"MAGNET",new Color(210,143,52));x+=120;}if(boost)powerBadge(g,x,95,"BOOST",new Color(230,95,90));}
        if(messageTime>0)center(g,message,640,145,new Font("SansSerif",Font.BOLD,27),new Color(75,63,91));
        if(paused){rounded(g,410,235,460,245,new Color(255,255,255,235));center(g,"PAUSED",640,300,titleFont,new Color(67,65,88));center(g,"Press P to continue",640,345,uiFont,new Color(95,95,105));button(g,"SETTINGS",new Rectangle(470,385,160,45),new Color(91,112,190));button(g,"QUIT",new Rectangle(650,385,160,45),new Color(210,91,104));}
    }
    void powerBadge(Graphics2D g,int x,int y,String s,Color c){rounded(g,x,y,105,36,new Color(255,255,255,215));text(g,s,x+10,y+24,uiFont,c);}
    void drawRunnerWorld(Graphics2D g,WorldType w){
        bg(g,w.sky,new Color(247,245,232));
        drawClouds(g); drawDistantWorld(g,w);

        // Camera presets. Cinematic = elevated over-the-shoulder runner perspective.
        boolean cinematic=cameraMode.equals("CINEMATIC");
        int horizon=cinematic?200:235;
        double sway=Math.sin(distance*0.014)*10;
        double topLeft=cinematic?560:525, topRight=cinematic?720:755;
        double botLeft=cinematic?50:95, botRight=cinematic?1230:1185;

        Path2D road=new Path2D.Double();
        road.moveTo(topLeft+sway*.25,horizon); road.lineTo(topRight+sway*.25,horizon);
        road.lineTo(botRight+sway,760); road.lineTo(botLeft+sway,760); road.closePath();
        g.setColor(w.road); g.fill(road);

        // Perspective road details anchored to the same vanishing point.
        g.setColor(new Color(255,255,255,65));
        for(int i=0;i<9;i++){
            double t=((i*0.135 + distance*0.00065)%1.0);
            double yy=horizon + Math.pow(t,0.82)*(760-horizon);
            double centerX=640+sway*(yy-horizon)/(760.0-horizon);
            double width=10+t*70;
            g.fillRoundRect((int)(centerX-width/2),(int)yy,(int)width,6,6,6);
        }
        g.setColor(new Color(255,255,255,88));
        for(int lane=1;lane<3;lane++){
            double topX=topLeft+(topRight-topLeft)*(lane/3.0)+sway*.25;
            double botX=botLeft+(botRight-botLeft)*(lane/3.0)+sway;
            Path2D line=new Path2D.Double(); line.moveTo(topX,horizon); line.lineTo(botX,760);
            g.setStroke(new BasicStroke(3)); g.draw(line);
        }

        drawSideDecor(g,w);
        for(Obstacle o:obstacles) drawObstacle(g,o);
        for(Coin c:coinList) drawCoin3D(g,c);
        for(Power p:powers) drawPower3D(g,p);

        // Monster starts farther back and moves toward the camera during the 5-6 second chase.
        if(monsterActive){
            int monsterY=(int)(500+threat*58);
            double monsterScale=.62+threat*.20;
            double monsterX=640+sway*.65;
            drawMonster(g,(int)monsterX,monsterY,monsterScale);
        }

        double py=cinematic?635:650;
        double px=laneX(lanePos,py);
        double baseScale=charSizeMode.equals("SMALL")?0.78:(charSizeMode.equals("LARGE")?1.18:1.00);
        drawCharacter(g,(int)px,(int)(py-jump),charIndex,baseScale,slide>0);

        // Strong contact shadow directly under the shoes.
        g.setColor(new Color(35,42,46,78));
        g.fillOval((int)px-(int)(45*baseScale),(int)py+(int)(64*baseScale),(int)(90*baseScale),(int)(16*baseScale));
    }
    double laneX(double lane,double y){
        boolean cinematic=cameraMode.equals("CINEMATIC");
        double horizon=cinematic?200:235;
        double topLeft=cinematic?560:525, topRight=cinematic?720:755;
        double botLeft=cinematic?50:95, botRight=cinematic?1230:1185;
        double t=Math.max(0,Math.min(1,(y-horizon)/(760.0-horizon)));
        double sway=Math.sin(distance*0.014)*10;
        double left=topLeft+sway*.25+(botLeft+sway-(topLeft+sway*.25))*t;
        double right=topRight+sway*.25+(botRight+sway-(topRight+sway*.25))*t;
        return left+(right-left)*(lane/2.0);
    }
    void drawClouds(Graphics2D g){g.setColor(new Color(255,255,255,180));for(int i=0;i<7;i++){int x=(int)((i*230-(distance*.7)%230));int y=70+(i%3)*45;g.fillOval(x,y,125,40);g.fillOval(x+35,y-22,90,60);}}
    void drawDistantWorld(Graphics2D g,WorldType w){
        g.setColor(w.distant);if(w==WorldType.CITY){for(int i=0;i<12;i++)drawBuilding(g,10+i*110,180+(i%4)*30,65,120-(i%4)*15);}else if(w==WorldType.VOLCANO){drawVolcano(g,980,165,1.8);}else if(w==WorldType.DESERT){for(int i=0;i<8;i++)drawCactus(g,40+i*165,260+(i%2)*20,.7);}else if(w==WorldType.SNOW){for(int i=0;i<9;i++)drawSnowTree(g,40+i*150,245+(i%2)*25,.65);}else if(w==WorldType.SKY){for(int i=0;i<8;i++)drawCloudIsland(g,40+i*170,245+(i%3)*20,.6);}else {for(int i=0;i<10;i++)drawTree(g,20+i*140,250+(i%3)*25,.65);}}
    void drawSideDecor(Graphics2D g,WorldType w){for(int i=0;i<6;i++){int y=330+i*75-(int)((distance*1.8)%75);if(y>270&&y<730){if(w==WorldType.FOREST){drawTree(g,50+(i%2)*115,y,.55+(y-300)/800.0);drawTree(g,1220-(i%2)*115,y,.55+(y-300)/800.0);}else if(w==WorldType.DESERT){drawCactus(g,50+(i%2)*120,y,.5+(y-300)/800.0);drawCactus(g,1220-(i%2)*120,y,.5+(y-300)/800.0);}else if(w==WorldType.SNOW){drawSnowTree(g,50+(i%2)*110,y,.55);drawSnowTree(g,1220-(i%2)*110,y,.55);}else if(w==WorldType.CITY){drawBuilding(g,20+(i%2)*120,y-80,70,100);drawBuilding(g,1190-(i%2)*120,y-80,70,100);}else if(w==WorldType.VOLCANO){drawRock(g,50+(i%2)*120,y,1);drawRock(g,1220-(i%2)*120,y,1);}else{drawCloudIsland(g,50+(i%2)*120,y,.5);drawCloudIsland(g,1220-(i%2)*120,y,.5);}}}}

    void drawObstacle(Graphics2D g,Obstacle o){if(o.z<0)return;double t=1-o.z/620.0;double y=280+t*420;double x=laneX(o.lane,y);double s=.35+t*1.25;switch(o.type){case 0->drawLog(g,(int)x,(int)y,s);case 1->drawRock(g,(int)x,(int)y,s);case 2->drawGate(g,(int)x,(int)y,s);case 3->drawCart(g,(int)x,(int)y,s);case 4->drawHole(g,(int)x,(int)y,s);default->drawFire(g,(int)x,(int)y,s);}}
    void drawCoin3D(Graphics2D g,Coin c){if(c.z<0)return;double t=1-c.z/620.0;double y=285+t*410;double x=laneX(c.lane,y);double s=.35+t*.9;drawCoin(g,(int)x,(int)(y-30),s);}
    void drawPower3D(Graphics2D g,Power p){ if(p.z<0)return; double t=1-p.z/700.0; double y=280+t*420; double x=laneX(p.lane,y); double sc=.5+t*.8; String s1=new String[]{"M","S","B","J"}[p.type]; g.setColor(new Color(255,255,255,210)); g.fillOval((int)(x-24*sc),(int)(y-24*sc),(int)(48*sc),(int)(48*sc)); int fs=Math.max(11,(int)(24*sc)); center(g,s1,(int)x,(int)y+8,new Font("SansSerif",Font.BOLD,fs),new Color(90,100,190)); }

    void drawEnd(Graphics2D g,boolean victory){bg(g,victory?new Color(180,220,178):new Color(226,190,200),new Color(247,239,226));drawMonster(g,960,505,1.02);drawCharacter(g,505,540,charIndex,1.10,false);rounded(g,130,120,720,480,new Color(255,255,255,225));center(g,victory?"YOU ESCAPED!":"GAME OVER",490,235,new Font("SansSerif",Font.BOLD,64),victory?new Color(75,178,96):new Color(218,88,103));center(g,victory?"You made it through the lost world.":"You hit an obstacle — the run ends instantly.",490,285,new Font("SansSerif",Font.PLAIN,22),new Color(85,85,95));text(g,"Score: "+score,250,350,headFont,new Color(65,65,75));text(g,"Coins: "+coins,250,395,headFont,new Color(180,125,20));text(g,"Best: "+save.best(),250,440,headFont,new Color(65,65,75));button(g,"PLAY AGAIN",new Rectangle(235,490,240,55),new Color(76,184,105));button(g,"MAIN MENU",new Rectangle(500,490,240,55),new Color(91,110,190));}

    void drawCharacter(Graphics2D g,int cx,int cy,int idx,double s,boolean sliding){
        CharacterData d=CharacterCatalog.DATA[idx];
        int swing=(int)(Math.sin(System.currentTimeMillis()/105.0)*12*s);
        int sx=(int)(cx-34*s), sy=(int)(cy-112*s), sw=(int)(68*s), sh=(int)(138*s);
        // Grounded shadow and contact glow.
        g.setColor(new Color(30,35,40,65));g.fillOval((int)(cx-42*s),cy+(int)(28*s),(int)(84*s),(int)(20*s));
        if(sliding){
            g.setStroke(new BasicStroke((float)(12*s),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
            g.setColor(d.pants);g.drawLine((int)(cx-30*s),cy,(int)(cx+37*s),cy+(int)(8*s));
            g.setColor(d.shirt);g.drawLine((int)(cx-2*s),cy-(int)(8*s),(int)(cx+37*s),cy-(int)(2*s));
            g.setColor(d.skin);g.fillOval((int)(cx+24*s),cy-(int)(36*s),(int)(31*s),(int)(31*s));
            g.setColor(d.hair);g.fillArc((int)(cx+23*s),cy-(int)(39*s),(int)(33*s),(int)(28*s),0,180);
            return;
        }
        // Legs: shaded pants, knees, ankle cuffs, and sneakers.
        int hipY=cy-(int)(5*s), kneeY=cy+(int)(30*s), footY=cy+(int)(62*s);
        g.setStroke(new BasicStroke((float)(15*s),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
        g.setColor(d.pants);g.drawLine(cx-(int)(12*s),hipY,(int)(cx-23*s+swing*.6),kneeY);g.drawLine(cx+(int)(12*s),hipY,(int)(cx+23*s-swing*.6),kneeY);
        g.setStroke(new BasicStroke((float)(11*s),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
        g.drawLine((int)(cx-23*s+swing*.6),kneeY,(int)(cx-29*s+swing),footY);g.drawLine((int)(cx+23*s-swing*.6),kneeY,(int)(cx+29*s-swing),footY);
        // White/gray running shoes with soles.
        int lx=(int)(cx-31*s+swing), rx=(int)(cx+31*s-swing);
        g.setColor(new Color(245,245,245));g.fillRoundRect(lx-(int)(17*s),footY-(int)(4*s),(int)(34*s),(int)(15*s),(int)(7*s),(int)(7*s));
        g.fillRoundRect(rx-(int)(17*s),footY-(int)(4*s),(int)(34*s),(int)(15*s),(int)(7*s),(int)(7*s));
        g.setColor(new Color(90,100,110));g.fillRoundRect(lx-(int)(17*s),footY+(int)(7*s),(int)(34*s),(int)(5*s),(int)(3*s),(int)(3*s));
        g.fillRoundRect(rx-(int)(17*s),footY+(int)(7*s),(int)(34*s),(int)(5*s),(int)(3*s),(int)(3*s));
        // Torso base with vertical highlight.
        g.setPaint(new GradientPaint(sx,sy,d.shirt,sx+sw,sy+sh,new Color(Math.max(0,d.shirt.getRed()-35),Math.max(0,d.shirt.getGreen()-35),Math.max(0,d.shirt.getBlue()-35))));
        g.fillRoundRect(sx,sy,sw,sh,24,24);g.setPaint(null);
        // Jacket zipper / center panel.
        g.setColor(new Color(255,255,255,105));g.fillRoundRect(cx-(int)(2*s),sy+(int)(7*s),(int)(4*s),(int)(102*s),4,4);
        // Arms with natural running swing and hands.
        g.setStroke(new BasicStroke((float)(13*s),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
        g.setColor(d.shirt);g.drawLine((int)(cx-29*s),sy+(int)(30*s),(int)(cx-43*s),cy+(int)(8*s+swing));
        g.drawLine((int)(cx+29*s),sy+(int)(30*s),(int)(cx+43*s),cy+(int)(8*s-swing));
        g.setColor(d.skin);g.fillOval((int)(cx-49*s),cy+(int)(2*s+swing),(int)(16*s),(int)(16*s));g.fillOval((int)(cx+37*s),cy+(int)(2*s-swing),(int)(16*s),(int)(16*s));
        // Neck + face with gentle shading.
        g.setColor(d.skin);g.fillRoundRect(cx-(int)(11*s),sy-(int)(17*s),(int)(22*s),(int)(22*s),7,7);
        g.setPaint(new GradientPaint(cx,sy-(int)(82*s),new Color(Math.min(255,d.skin.getRed()+16),Math.min(255,d.skin.getGreen()+16),Math.min(255,d.skin.getBlue()+16)),cx,sy-(int)(35*s),d.skin));
        g.fillOval((int)(cx-28*s),sy-(int)(88*s),(int)(56*s),(int)(58*s));g.setPaint(null);
        // Hair volume and highlights.
        g.setColor(d.hair);g.fillArc((int)(cx-31*s),sy-(int)(93*s),(int)(62*s),(int)(58*s),0,180);
        g.setColor(new Color(255,255,255,70));g.fillOval((int)(cx-16*s),sy-(int)(79*s),(int)(10*s),(int)(6*s));
        // Brows, eyes, nose and small smile.
        g.setStroke(new BasicStroke((float)(3*s),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));g.setColor(new Color(65,50,50));
        g.drawLine((int)(cx-16*s),sy-(int)(65*s),(int)(cx-7*s),sy-(int)(66*s));g.drawLine((int)(cx+7*s),sy-(int)(66*s),(int)(cx+16*s),sy-(int)(65*s));
        g.setColor(Color.WHITE);g.fillOval((int)(cx-13*s),sy-(int)(58*s),(int)(10*s),(int)(10*s));g.fillOval((int)(cx+3*s),sy-(int)(58*s),(int)(10*s),(int)(10*s));
        g.setColor(new Color(50,50,55));g.fillOval((int)(cx-9*s),sy-(int)(55*s),(int)(4*s),(int)(5*s));g.fillOval((int)(cx+7*s),sy-(int)(55*s),(int)(4*s),(int)(5*s));
        g.drawLine(cx,(int)(sy-48*s),(int)(cx+2*s),(int)(sy-44*s));
        g.drawLine((int)(cx-7*s),sy-(int)(39*s),(int)(cx+7*s),sy-(int)(39*s));
        // Small outfit detail / stripe makes each character more distinct.
        g.setColor(new Color(255,255,255,80));g.fillRoundRect(sx+(int)(10*s),sy+(int)(88*s),(int)(sw-20*s),(int)(7*s),5,5);
    }
    void drawMonster(Graphics2D g,int cx,int cy,double s){
        // A darker, grounded hunter silhouette rather than a toy-like mascot.
        int bob=(int)(Math.sin(System.currentTimeMillis()/210.0)*3*s); cy+=bob;
        g.setColor(new Color(20,24,28,95));
        g.fillOval((int)(cx-82*s), cy+(int)(52*s), (int)(164*s), (int)(28*s));

        // Long legs and feet keep the monster visually on the road.
        g.setStroke(new BasicStroke((float)(18*s),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
        g.setColor(new Color(38,34,44));
        int stride=(int)(Math.sin(System.currentTimeMillis()/150.0)*13*s);
        g.drawLine((int)(cx-30*s),cy+(int)(30*s),(int)(cx-44*s)+stride,cy+(int)(66*s));
        g.drawLine((int)(cx+30*s),cy+(int)(30*s),(int)(cx+44*s)-stride,cy+(int)(66*s));
        g.setStroke(new BasicStroke((float)(13*s),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
        g.setColor(new Color(25,23,29));
        g.drawLine((int)(cx-44*s)+stride,cy+(int)(66*s),(int)(cx-63*s)+stride,cy+(int)(76*s));
        g.drawLine((int)(cx+44*s)-stride,cy+(int)(66*s),(int)(cx+63*s)-stride,cy+(int)(76*s));

        // Body and shoulders.
        g.setColor(new Color(47,42,54));
        g.fillRoundRect((int)(cx-58*s),cy-(int)(84*s),(int)(116*s),(int)(122*s),(int)(34*s),(int)(34*s));
        g.setColor(new Color(58,50,69));
        g.fillOval((int)(cx-72*s),cy-(int)(60*s),(int)(38*s),(int)(90*s));
        g.fillOval((int)(cx+34*s),cy-(int)(60*s),(int)(38*s),(int)(90*s));

        // Head with angular silhouette.
        Path2D head=new Path2D.Double();
        head.moveTo(cx-52*s, cy-(int)(116*s));
        head.quadTo(cx, cy-(int)(154*s), cx+52*s, cy-(int)(116*s));
        head.lineTo(cx+44*s, cy-(int)(45*s));
        head.quadTo(cx, cy-(int)(18*s), cx-44*s, cy-(int)(45*s));
        head.closePath();
        g.setColor(new Color(30,27,36)); g.fill(head);

        // Horns / ears.
        Path2D horn=new Path2D.Double();
        horn.moveTo(cx-34*s,cy-(int)(112*s)); horn.lineTo(cx-74*s,cy-(int)(163*s)); horn.lineTo(cx-13*s,cy-(int)(126*s)); horn.closePath();
        g.setColor(new Color(84,72,94)); g.fill(horn);
        horn=new Path2D.Double();
        horn.moveTo(cx+34*s,cy-(int)(112*s)); horn.lineTo(cx+74*s,cy-(int)(163*s)); horn.lineTo(cx+13*s,cy-(int)(126*s)); horn.closePath(); g.fill(horn);

        // Narrow glowing eyes and a tense jaw.
        g.setColor(new Color(232,202,86));
        g.fillRoundRect((int)(cx-31*s),cy-(int)(80*s),(int)(24*s),(int)(11*s),6,6);
        g.fillRoundRect((int)(cx+7*s),cy-(int)(80*s),(int)(24*s),(int)(11*s),6,6);
        g.setColor(new Color(32,26,35));
        g.fillRect((int)(cx-9*s),cy-(int)(49*s),(int)(18*s),(int)(36*s));
        g.setStroke(new BasicStroke((float)(4*s),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
        g.setColor(new Color(118,103,133));
        g.drawArc((int)(cx-26*s),cy-(int)(41*s),(int)(52*s),(int)(30*s),200,140);

        // Arms reach forward slightly as if chasing.
        g.setStroke(new BasicStroke((float)(17*s),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
        g.setColor(new Color(46,41,54));
        g.drawLine((int)(cx-52*s),cy-(int)(34*s),(int)(cx-80*s),cy+(int)(8*s));
        g.drawLine((int)(cx+52*s),cy-(int)(34*s),(int)(cx+80*s),cy+(int)(8*s));
        g.setColor(new Color(118,104,133));
        g.fillOval((int)(cx-90*s),cy+(int)(0*s),(int)(18*s),(int)(18*s));
        g.fillOval((int)(cx+72*s),cy+(int)(0*s),(int)(18*s),(int)(18*s));
    }

    void drawTree(Graphics2D g,int x,int y,double s){g.setColor(new Color(119,86,58));g.fillRoundRect((int)(x-9*s),y,(int)(18*s),(int)(70*s),8,8);g.setColor(new Color(104,174,93));g.fillOval((int)(x-55*s),y-(int)(60*s),(int)(110*s),(int)(100*s));g.setColor(new Color(128,193,103));g.fillOval((int)(x-35*s),y-(int)(80*s),(int)(90*s),(int)(80*s));}
    void drawSnowTree(Graphics2D g,int x,int y,double s){g.setColor(new Color(111,87,68));g.fillRect((int)(x-7*s),y,(int)(14*s),(int)(60*s));g.setColor(new Color(180,208,226));for(int i=0;i<3;i++)g.fillOval((int)(x-(40-i*10)*s),y-(int)((35+i*27)*s),(int)((80-i*12)*s),(int)((55-i*5)*s));}
    void drawCactus(Graphics2D g,int x,int y,double s){g.setColor(new Color(89,168,100));g.fillRoundRect((int)(x-13*s),y-(int)(65*s),(int)(26*s),(int)(100*s),16,16);g.fillRoundRect((int)(x-42*s),y-(int)(38*s),(int)(30*s),(int)(15*s),12,12);g.fillRoundRect((int)(x+12*s),y-(int)(20*s),(int)(30*s),(int)(15*s),12,12);}
    void drawBuilding(Graphics2D g,int x,int y,int w,int h){g.setColor(new Color(114,128,156,210));g.fillRoundRect(x,y,w,h,8,8);g.setColor(new Color(244,221,139));for(int yy=y+15;yy<y+h-10;yy+=28)for(int xx=x+10;xx<x+w-10;xx+=24)g.fillRoundRect(xx,yy,12,15,3,3);}
    void drawVolcano(Graphics2D g,int x,int y,double s){Path2D p=new Path2D.Double();p.moveTo(x-180*s,y+130*s);p.lineTo(x-55*s,y-50*s);p.lineTo(x+5*s,y-15*s);p.lineTo(x+75*s,y-80*s);p.lineTo(x+190*s,y+130*s);p.closePath();g.setColor(new Color(110,92,90));g.fill(p);g.setColor(new Color(235,107,75));g.fillOval((int)(x-58*s), (int)(y-62*s),(int)(115*s),(int)(45*s));}
    void drawCloudIsland(Graphics2D g,int x,int y,double s){g.setColor(new Color(255,255,255,190));g.fillOval((int)(x-55*s),y-(int)(30*s),(int)(110*s),(int)(55*s));g.fillOval((int)(x-20*s),y-(int)(55*s),(int)(75*s),(int)(65*s));g.setColor(new Color(187,168,140));Path2D p=new Path2D.Double();p.moveTo(x-30*s,y+15*s);p.lineTo(x+30*s,y+15*s);p.lineTo(x+5*s,y+75*s);p.closePath();g.fill(p);}
    void drawMushroom(Graphics2D g,int x,int y,double s){g.setColor(new Color(225,95,98));g.fillArc((int)(x-30*s),(int)(y-35*s),(int)(60*s),(int)(55*s),0,180);g.setColor(Color.WHITE);for(int i=0;i<3;i++)g.fillOval((int)(x+(-20+i*18)*s),(int)(y-25*s),(int)(8*s),(int)(8*s));g.setColor(new Color(239,217,180));g.fillRoundRect((int)(x-9*s),y-(int)(5*s),(int)(18*s),(int)(40*s),8,8);}
    void drawRock(Graphics2D g,int x,int y,double s){g.setColor(new Color(135,128,122));Path2D p=new Path2D.Double();p.moveTo(x-35*s,y);p.lineTo(x-22*s,y-28*s);p.lineTo(x+12*s,y-35*s);p.lineTo(x+35*s,y-8*s);p.lineTo(x+20*s,y+12*s);p.lineTo(x-18*s,y+14*s);p.closePath();g.fill(p);}
    void drawLog(Graphics2D g,int x,int y,double s){g.setColor(new Color(128,83,48));g.fillRoundRect((int)(x-55*s),y-(int)(22*s),(int)(110*s),(int)(44*s),16,16);g.setColor(new Color(182,126,76));g.fillOval((int)(x+30*s),y-(int)(22*s),(int)(44*s),(int)(44*s));}
    void drawGate(Graphics2D g,int x,int y,double s){g.setColor(new Color(120,76,50));g.fillRoundRect((int)(x-60*s),y-(int)(110*s),(int)(20*s),(int)(110*s),8,8);g.fillRoundRect((int)(x+40*s),y-(int)(110*s),(int)(20*s),(int)(110*s),8,8);g.fillRoundRect((int)(x-60*s),y-(int)(110*s),(int)(120*s),(int)(20*s),8,8);}
    void drawCart(Graphics2D g,int x,int y,double s){g.setColor(new Color(226,119,63));g.fillRoundRect((int)(x-55*s),y-(int)(48*s),(int)(110*s),(int)(48*s),10,10);g.setColor(new Color(65,65,70));g.fillOval((int)(x-40*s),y-(int)(8*s),(int)(22*s),(int)(22*s));g.fillOval((int)(x+18*s),y-(int)(8*s),(int)(22*s),(int)(22*s));}
    void drawHole(Graphics2D g,int x,int y,double s){g.setColor(new Color(58,58,60));g.fillOval((int)(x-65*s),y-(int)(18*s),(int)(130*s),(int)(36*s));g.setColor(new Color(94,75,62));g.drawOval((int)(x-60*s),y-(int)(15*s),(int)(120*s),(int)(30*s));}
    void drawFire(Graphics2D g,int x,int y,double s){g.setColor(new Color(225,93,63));g.fillOval((int)(x-35*s),y-(int)(55*s),(int)(70*s),(int)(75*s));g.setColor(new Color(249,190,70));g.fillOval((int)(x-18*s),y-(int)(35*s),(int)(36*s),(int)(55*s));}
    void drawCoin(Graphics2D g,int x,int y,double s){g.setColor(new Color(246,193,50));g.fillOval((int)(x-13*s),y-(int)(13*s),(int)(26*s),(int)(26*s));g.setColor(new Color(255,231,118));g.drawOval((int)(x-8*s),y-(int)(8*s),(int)(16*s),(int)(16*s));}

    public void mousePressed(int x,int y){
        if(screen==Screen.MENU){
            if(playBtn.contains(x,y)){resetGame();}
            else if(new Rectangle(78,316,356,45).contains(x,y)){go(Screen.CHARACTERS);sound.click();}
            else if(new Rectangle(78,369,356,45).contains(x,y)){go(Screen.WORLDS);sound.click();}
            else if(new Rectangle(78,422,356,45).contains(x,y)){go(Screen.SHOP);sound.click();}
            else if(new Rectangle(78,475,356,45).contains(x,y)){go(Screen.MISSIONS);sound.click();}
            else if(new Rectangle(78,528,356,45).contains(x,y)){openSettings();sound.click();}
        }
        else if(screen==Screen.CHARACTERS){for(int i=0;i<10;i++){int col=i%5,row=i/5,x0=40+col*242,y0=125+row*275;if(new Rectangle(x0,y0,220,250).contains(x,y)){charIndex=i;save.selectedChar(i);sound.click();}}if(new Rectangle(30,690,150,45).contains(x,y))go(Screen.MENU);}
        else if(screen==Screen.WORLDS){for(int i=0;i<6;i++){int col=i%3,row=i/3,x0=45+col*410,y0=125+row*260;if(new Rectangle(x0,y0,380,230).contains(x,y)){worldIndex=i;save.selectedWorld(i);sound.click();}}if(new Rectangle(30,690,150,45).contains(x,y))go(Screen.MENU);}
        else if(screen==Screen.SETTINGS){
            if(new Rectangle(850,132,150,42).contains(x,y)){musicOn=!musicOn;applyAudio();sound.click();}
            else if(new Rectangle(850,188,150,42).contains(x,y)){sfxOn=!sfxOn;applyAudio();sound.click();}
            else if(new Rectangle(500,250,140,42).contains(x,y)){difficulty="EASY";save.difficulty(difficulty);sound.click();}
            else if(new Rectangle(650,250,150,42).contains(x,y)){difficulty="NORMAL";save.difficulty(difficulty);sound.click();}
            else if(new Rectangle(810,250,140,42).contains(x,y)){difficulty="HARD";save.difficulty(difficulty);sound.click();}
            else if(new Rectangle(500,319,175,42).contains(x,y)){cameraMode="CINEMATIC";save.camera(cameraMode);sound.click();}
            else if(new Rectangle(690,319,150,42).contains(x,y)){cameraMode="CLASSIC";save.camera(cameraMode);sound.click();}
            else if(new Rectangle(500,388,140,42).contains(x,y)){charSizeMode="SMALL";save.charSize(charSizeMode);sound.click();}
            else if(new Rectangle(650,388,150,42).contains(x,y)){charSizeMode="NORMAL";save.charSize(charSizeMode);sound.click();}
            else if(new Rectangle(810,388,140,42).contains(x,y)){charSizeMode="LARGE";save.charSize(charSizeMode);sound.click();}
            else if(new Rectangle(245,594,185,42).contains(x,y)){int ans=JOptionPane.showConfirmDialog(this,"Reset characters, worlds, coins, best score and settings?","Reset Progress",JOptionPane.YES_NO_OPTION);if(ans==JOptionPane.YES_OPTION){save.reset();charIndex=0;worldIndex=0;soundOn=true;musicOn=true;sfxOn=true;difficulty="NORMAL";cameraMode="CINEMATIC";charSizeMode="NORMAL";
save.selectedChar(0);save.selectedWorld(0);save.difficulty(difficulty);save.camera(cameraMode);save.charSize(charSizeMode);applyAudio();sound.click();}}
            else if(new Rectangle(455,594,150,42).contains(x,y)){closeSettings();}
            else if(new Rectangle(625,594,185,42).contains(x,y)){closeSettings();}
        }
        else if(screen==Screen.MISSIONS||screen==Screen.SHOP){if(new Rectangle(30,690,150,45).contains(x,y))go(Screen.MENU);}
        else if(screen==Screen.GAME && paused){
            if(new Rectangle(470,385,160,45).contains(x,y)){openSettings();sound.click();}
            else if(new Rectangle(650,385,160,45).contains(x,y)){playing=false;go(Screen.MENU);sound.playMenuMusic();}
        }
        else if(screen==Screen.GAMEOVER||screen==Screen.VICTORY){if(new Rectangle(235,490,240,55).contains(x,y)){resetGame();}else if(new Rectangle(500,490,240,55).contains(x,y))go(Screen.MENU);}
    }
    public void mouseReleased(MouseEvent e){} public void mouseEntered(MouseEvent e){} public void mouseExited(MouseEvent e){} public void mouseClicked(MouseEvent e){mousePressed(e.getX(),e.getY());}
    public void keyPressed(KeyEvent e){int k=e.getKeyCode();if(screen==Screen.GAME){if(k==KeyEvent.VK_P){paused=!paused;return;}if(paused)return;if(k==KeyEvent.VK_LEFT||k==KeyEvent.VK_A)laneTarget=Math.max(0,laneTarget-1);if(k==KeyEvent.VK_RIGHT||k==KeyEvent.VK_D)laneTarget=Math.min(2,laneTarget+1);if(k==KeyEvent.VK_UP||k==KeyEvent.VK_W||k==KeyEvent.VK_SPACE){if(jump==0&&slide<=0){verticalVel=570;missionJumps++;sound.play(1);}}if(k==KeyEvent.VK_DOWN||k==KeyEvent.VK_S){slide=.75;sound.slide();}}
        else if(k==KeyEvent.VK_ESCAPE){if(screen==Screen.SETTINGS) closeSettings(); else go(Screen.MENU);} }
    public void keyReleased(KeyEvent e){} public void keyTyped(KeyEvent e){}
}


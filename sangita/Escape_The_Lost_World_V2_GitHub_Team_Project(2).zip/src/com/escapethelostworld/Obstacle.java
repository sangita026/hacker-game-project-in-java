package com.escapethelostworld;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.util.*;
import java.util.List;


class Obstacle {int lane,type;double z;boolean hit,passed;Obstacle(int l,double z,int t){lane=l;this.z=z;type=t;}}


package com.escapethelostworld;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.util.*;
import java.util.List;


enum Screen { MENU, CHARACTERS, WORLDS, SHOP, MISSIONS, SETTINGS, GAME, GAMEOVER, VICTORY }


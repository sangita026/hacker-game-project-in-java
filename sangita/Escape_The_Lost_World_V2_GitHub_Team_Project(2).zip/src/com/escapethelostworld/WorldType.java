package com.escapethelostworld;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.util.*;
import java.util.List;


enum WorldType {
    FOREST("Enchanted Forest", new Color(174, 220, 137), new Color(112, 177, 92), new Color(239, 215, 158)),
    DESERT("Desert Valley", new Color(246, 211, 149), new Color(214, 164, 99), new Color(236, 191, 118)),
    CITY("Sunny Metro City", new Color(171, 214, 235), new Color(110, 165, 196), new Color(126, 126, 133)),
    SNOW("Snow Mountain", new Color(211, 235, 247), new Color(148, 190, 216), new Color(232, 238, 241)),
    VOLCANO("Volcano Valley", new Color(244, 187, 151), new Color(157, 96, 81), new Color(89, 83, 88)),
    SKY("Sky Kingdom", new Color(191, 222, 249), new Color(133, 184, 218), new Color(217, 190, 150));
    final String title; final Color sky, distant, road;
    WorldType(String t, Color s, Color d, Color r) { title=t; sky=s; distant=d; road=r; }
}

